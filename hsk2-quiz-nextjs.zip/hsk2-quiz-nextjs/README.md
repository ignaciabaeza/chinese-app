# HSK 2 Reading Quiz — Next.js drop-in

A self-contained reading quiz for *HSK 标准教程 2 · 练习册* (Standard Course 2 Workbook):
15 lessons × 15 questions = **225 questions** (5 picture-matching, 5 fill-in-the-blank,
5 true/false per lesson). No external dependencies, no audio, no browser storage.

## What's in this package

```
components/
  HSK2Quiz.jsx          ← React client component (the whole quiz UI + logic)
  HSK2Quiz.module.css   ← scoped styles
data/
  quizData.js           ← all 225 questions; image refs are filenames only
public/
  hsk2/images/          ← 90 photos: lesson-<1-15>-<A-F>.jpg
```

## Install into your app (3 steps)

1. **Images** — copy the `public/hsk2` folder into your project's existing `public/`
   directory. The files must end up at `public/hsk2/images/lesson-1-A.jpg`, etc., so
   they're served from the URL `/hsk2/images/...`.

2. **Component + data** — copy `components/HSK2Quiz.jsx`,
   `components/HSK2Quiz.module.css`, and `data/quizData.js` anywhere in your source
   tree. Keep `HSK2Quiz.jsx` and `quizData.js` in sibling `components/` and `data/`
   folders, or fix the import path at the top of `HSK2Quiz.jsx`
   (`import { LESSONS } from '../data/quizData'`). Using a path alias like
   `@/data/quizData` is fine too.

3. **Render it.**

   App Router — `app/quiz/page.js`:
   ```jsx
   import HSK2Quiz from '@/components/HSK2Quiz';
   export default function Page() {
     return <HSK2Quiz />;
   }
   ```

   Pages Router — `pages/quiz.js`:
   ```jsx
   import HSK2Quiz from '../components/HSK2Quiz';
   export default function Quiz() {
     return <HSK2Quiz />;
   }
   ```

`HSK2Quiz.jsx` is already marked `'use client'`, so it works in either router.

## Options

If you put the images somewhere other than `/hsk2/images`, pass the base URL:

```jsx
<HSK2Quiz imageBase="/assets/hsk2" />
```

## Data shape (`quizData.js`)

```js
export const LESSONS = [
  {
    id: 1,
    zh: "九月去北京旅游最好",
    pinyin: "Jiǔ yuè qù Běijīng lǚyóu zuì hǎo",
    en: "September is the best time to visit Beijing",
    images: { A: "lesson-1-A.jpg", /* ...B–F */ },
    questions: [
      // type: "picture" — { prompt, pinyin, en, answer: "A".."F", explain }
      // type: "fill"    — { prompt (contains "___"), pinyin, en, options:[{k,zh,py,en}], answer, explain }
      // type: "tf"      — { context, contextPy, contextEn, statement, statementPy, statementEn, answer:bool, explain }
    ]
  },
  // ...lessons 2–15
];
```

Picture questions reference the six images by their lesson-level `images` map; the
component builds the final `src` as `` `${imageBase}/${images[answerLetter]}` ``.

## Notes on the content

- **Listening** sections are intentionally excluded — the source PDF has no audio.
- The **basketball photo (always option D)** is the workbook's worked example. It
  appears as a choice but is never the correct answer to questions 16–20, so it acts
  as a distractor.
- The workbook ships **no official answer key**; every answer here was derived by
  reading the text. The reading items are unambiguous, but if you obtain the official
  key you may want to spot-check.

## Customizing

- **Styling** — edit `HSK2Quiz.module.css`. Colors are CSS variables at the top
  (`--seal` is the vermilion accent, `--jade` is "correct").
- **Images** — they're plain `<img>` tags pointing at `/public`. If you'd rather use
  `next/image`, swap the `<img>` in the `picture` branch of `HSK2Quiz.jsx` for
  `<Image fill .../>` inside a sized wrapper.
- **Editing questions** — everything lives in `quizData.js`; no code changes needed to
  reword prompts, fix a translation, or change an answer.
